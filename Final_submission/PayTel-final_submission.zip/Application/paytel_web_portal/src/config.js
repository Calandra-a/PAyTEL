export default {
  apiGateway: {
    REGION: "us-east-1",
    URL: "https://4cao01l38k.execute-api.us-east-1.amazonaws.com/prod"
  },
  cognito: {
    REGION: "us-east-1",
    USER_POOL_ID: "us-east-1_XZ6DotKrH",
    APP_CLIENT_ID: "3rhm7nkj5m5vqgv7siu6ag4ebh",
    IDENTITY_POOL_ID: "us-east-1:81636298-fbfc-4274-93be-cc8ae950cb93"
  }
};
