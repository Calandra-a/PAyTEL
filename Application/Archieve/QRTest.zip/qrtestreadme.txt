add:
implementation 'com.journeyapps:zxing-android-embedded:3.6.0'
to build.grade (module) file
