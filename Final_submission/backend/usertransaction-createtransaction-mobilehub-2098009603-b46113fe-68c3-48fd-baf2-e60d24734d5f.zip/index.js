const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const uuidv1 = require('uuid/v1');
const docClient = new AWS.DynamoDB.DocumentClient();
'use strict';
//event bodycontains 
    //seller_user_id
    //buyer_username (not id)
    //amount
    

exports.handler = function(event, context, callback) {
    var requestBody = JSON.parse(event.body);
    //var requestBody = event.body;
    var seller_user_id = requestBody.seller_user_id;
    var seller_username = requestBody.seller_username;
    var buyer_un = requestBody.buyer_username;
    var transaction_amount = requestBody.amount;
    var transaction_note = requestBody.note;

    var transaction_id = uuidv1();
    var curr_time = String(new Date(Date.now()).toString());
    var buyer_user_id;
    
    var params_queryUsername = {
        TableName : "paytel-mobilehub-2098009603-user-data",
        IndexName: "username1",
        KeyConditionExpression: "username = :un",
        ExpressionAttributeValues: {
            ":un": {S: buyer_un}
        },
        ProjectionExpression:"userId"
    };
    
    ddb.query(params_queryUsername, function(err, data) {
    if (err) {
        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        Response({message:"DB error_un"}, 400, context);
        return;
    } else {
        console.log("Query succeeded.");
       console.log(data.Items[0]);
        if(data.Items[0] === undefined){
           Response({message:"Username not found"}, 220, context);
           return;
        }
         var buyer_user_id = data.Items[0].userId.S;
        
        var params_transaction = {
              TableName: 'paytel-mobilehub-2098009603-transactions',
              Item: {
                'transaction_id' : {S: transaction_id},
                'buyer_id' : {S: buyer_user_id},
                'buyer_username':{S: buyer_un},
                'seller_id':{S: seller_user_id},
                'seller_username':{S:seller_username},
                'amount' : {S: transaction_amount},
                'note' : {S: transaction_note},
                'time_created': {S: curr_time},
                'transaction_status':{S: 'Pending'},
              }
        };
    
        ddb.putItem(params_transaction, function(err, data) {
          if (err) {
            console.log("Error", err);
            Response({message:"DB error_trans",parameters: JSON.stringify(params_transaction)}, 400, context);
            return;
          } else {
            console.log("Success", data);
            //attach transaction to users 
            var params_buyer = {
              TableName:'paytel-mobilehub-2098009603-user-data',
              Key:{
                  "userId": buyer_user_id
              },
              UpdateExpression: "ADD transactions :transID",
              ExpressionAttributeValues:{
                 ':transID': docClient.createSet([transaction_id])
              },
              ReturnValues:"NONE"
          };
          var params_seller = {
              TableName:'paytel-mobilehub-2098009603-user-data',
              Key:{
                  "userId": seller_user_id
              },
              UpdateExpression: "ADD transactions :transID",
              ExpressionAttributeValues:{
                  ':transID': docClient.createSet([transaction_id])
                    
              },
              ReturnValues:"NONE"
          };
          docClient.update(params_buyer, function(err, data) {
              if (err) {
                  console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
              } else {
                  console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
              }
              docClient.update(params_seller, function(err, data) {
              if (err) {
                  console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
              } else {
                  console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
              }
              Response({message:"Transaction created"}, 200, context);
              }); 
          });  
          
            
        
           
          }
        });
    }
  });

};

function Response(responseBody, responseCode, context){
    var response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "Transaction"
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response));
    context.succeed(response);
}