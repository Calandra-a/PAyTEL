package com.example.qr.qrtest;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class QRCodeGen extends AppCompatActivity {

    Button generate_QRCode;
    ImageView qrCode;
    EditText mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_gen);
        generate_QRCode = (Button) findViewById(R.id.generate_qr);
        qrCode = (ImageView) findViewById(R.id.imageView);
        mEditText = (EditText) findViewById(R.id.editText);

        generate_QRCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = mEditText.getText().toString();
                // MultiFormatWriter is part of zxing, finds appropriate Writer subclass for
                // BarcodeFormat requested and encodes the barcode with the supplied contents.
                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                try {
                    //BitMatrix represents 2D matrix of bits, encode function takes
                    // (String contents, BardcodeFormat format, int width, int height)
                    // text is what is being converted to qr code, change this to the user id
                    // (must be formatted to String)
                    BitMatrix bitMatrix = multiFormatWriter.encode(text, BarcodeFormat.QR_CODE,400,400);
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                    Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                    qrCode.setImageBitmap(bitmap);
                } catch (WriterException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
