const AWS = require("aws-sdk");
const rekognition = new AWS.Rekognition({apiVersion: '2016-06-27'});
var s3 = new AWS.S3();
var async = require("async");


exports.handler = function(event, context, callback) {
  var confidenceLevel = 0;
   var requestBody = JSON.parse(event.body);
    //var requestBody = event.body;
 
    var user_id = requestBody.userID;
    var face_pose = requestBody.pose;
    var user_id_split = user_id.split(':');
    var collectionID = 'paytel-'+user_id_split[1];
    var S3Key = requestBody.S3Key;
    
    async.waterfall([
      (next) => {
        var rekParams = {
            CollectionId: collectionID,
            FaceMatchThreshold: 92, 
            Image: {
                "S3Object": { 
                     "Bucket": "paytel-userfiles-mobilehub-2098009603",
                     "Name": S3Key,
                  }
            }
        }; 
        rekognition.searchFacesByImage(rekParams, function(err, data) {
          if (err){
              return output(400,{message: "No face detected!"}, callback);
             // return callback(err);
          }else {  
              console.log(data);
              if(data.FaceMatches.length > 0){
                  confidenceLevel = data.FaceMatches[0].Face.Confidence.toFixed(2);
                  next(null);
              }else{
                  return output(400,{message: "Wrong user!"}, callback);
              }
          }
        });
        
      },
      (next) => {
          var rekParams = {
            CollectionId: collectionID,
            Image: {
                "S3Object": { 
                     "Bucket": "paytel-userfiles-mobilehub-2098009603",
                     "Name": S3Key,
                  }
            },
            DetectionAttributes: ["ALL"]
        }; 
        rekognition.indexFaces(rekParams, function(err, data){
            if(err){
                console.log(JSON.stringify(err));
                return callback(null);
            }else{
                if(data.FaceRecords[0] === undefined){
                    return callback(err);
                }else{
                    var msg = "";
                    switch(face_pose){
                      case "mouth open":
                          if(data.FaceRecords[0].FaceDetail.MouthOpen.Value == true && data.FaceRecords[0].FaceDetail.MouthOpen.Confidence >= 80){
                            msg = "User verfied with a confidence of "+confidenceLevel+"%";
                          }
                        break;
                      case "close eyes":
                          if(data.FaceRecords[0].FaceDetail.EyesOpen.Value == false && data.FaceRecords[0].FaceDetail.EyesOpen.Confidence >= 80){
                            msg = "User verfied with a confidence of "+confidenceLevel+"%";
                          }
                        break;
                      case "frown":
                        data.FaceRecords[0].FaceDetail.Emotions.forEach(function(val){
                          if(val.Type == "SAD"){
                            msg = "User verfied with a confidence of "+confidenceLevel+"%";
                          }
                        });
                        break;
                    }
                    if(msg != ""){
                      next(null, {message: msg});
                    }else{
                      return output(400,{message: "Pose incorrect!"}, callback);
                    }
                }
            }
        });
         
      }
    ],
    (err, res) => {
      if (err) return callback(err);
      output(200, res, callback);
    });
};

const output = (statusCode, data, callback) => {
  callback(null,
    {
      'statusCode': statusCode,
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      'body': JSON.stringify(data)
    }
  );
}