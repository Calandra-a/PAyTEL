const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const docClient = new AWS.DynamoDB.DocumentClient();


function Response(responseBody, responseCode, context){
    var response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "Transaction",
            "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response));
    context.succeed(response);
    return;
}
'use strict';

exports.handler = function(event, context, callback) {
    var queryStringParams = event.queryStringParameters;
    var usern = event.pathParameters.user_id;
  
    
    var returnObj = {};
    //query user
    var params_queryUsername = {
        TableName : "paytel-mobilehub-2098009603-user-data",
        IndexName: "username1",
        KeyConditionExpression: "username = :un",
        ExpressionAttributeValues: {
            ":un": {S: usern}
        }
    };
     ddb.query(params_queryUsername, function(err, data) {
    if (err) {
        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        Response({message:"DB error_un"}, 400, context);
        return;
    } else {
        returnObj.user_id = data.Items[0].userId.S;
        returnObj.first_name = data.Items[0].first_name.S;
        returnObj.last_name = data.Items[0].last_name.S;
        returnObj.username = data.Items[0].username.S;
        returnObj.phone_number = data.Items[0].phone_number.S;
        returnObj.address = {};
            returnObj.address.street = data.Items[0].street.S;
            returnObj.address.zip_code = data.Items[0].zip_code.S;
            returnObj.address.state = data.Items[0].state.S;
             returnObj.address.city = data.Items[0].city.S;
        returnObj.credit_card = {};
            returnObj.credit_card.number = data.Items[0].credit_card.M.card_number.S.substr(data.Items[0].credit_card.M.card_number.S.length - 4);
            returnObj.credit_card.expiration_date= data.Items[0].credit_card.M.expiration_date.S;
            returnObj.credit_card.name_on_card = data.Items[0].credit_card.M.name_on_card.S;
        returnObj.transactions =  data.Items[0].transactions.SS;
        
        console.log(returnObj);
        Response({"user_info": returnObj},200, context)
    }
    });
};