const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const docClient = new AWS.DynamoDB.DocumentClient();


function Response(responseBody, responseCode, context){
    var response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "Transaction",
            "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response));
    context.succeed(response);
    return;
}
'use strict';

exports.handler = function(event, context, callback) {
    var queryStringParams = event.queryStringParameters;
    var trans_id = queryStringParams.transid;
  
    var params_getTransaction ={
            TableName:'paytel-mobilehub-2098009603-transactions',
              Key:{
                  "transaction_id": trans_id
              },
              UpdateExpression: "SET transaction_status = :st",
                            ExpressionAttributeValues:{
                                 ':st': 'flagged'
                            },
             ReturnValues:"NONE"
        }
         docClient.update(params_getTransaction, function(err,dataTrans){
                if(err){
                    console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    Response({message:"DB error_un"}, 400, context);
                    return;
                }else{
                    Response({message:"transaction flagged"}, 200, context);
                }
         });
         
};