const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const docClient = new AWS.DynamoDB.DocumentClient();


function Response(responseBody, responseCode, context){
    var response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "Transaction",
            "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response));
    context.succeed(response);
    return;
}
'use strict';

exports.handler = function(event, context, callback) {
    var params = {
        TableName:'paytel-mobilehub-2098009603-transactions',
        ProjectionExpression:"amount, buyer_username, seller_username, note, time_created, biometric_used, time_last_edit, transaction_status"
    };
    
    docClient.scan(params, function(err, data) {
        if (err) {
            Response({message:"DB error_un"}, 400, context);
            console.log("Unable to query. Error:", JSON.stringify(err, null, 2));
        } else {
            console.log("Query succeeded.");
            Response({transactions:data.Items}, 200, context);
           
        }
    });
};