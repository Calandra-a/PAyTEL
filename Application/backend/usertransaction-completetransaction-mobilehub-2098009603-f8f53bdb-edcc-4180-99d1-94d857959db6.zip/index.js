const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const uuidv1 = require('uuid/v1');
const docClient = new AWS.DynamoDB.DocumentClient();
'use strict';
//event bodycontains 
    //seller_user_id
    //buyer_username (not id)
    //amount


exports.handler = function(event, context, callback) {
    var requestBody = JSON.parse(event.body);
    //var requestBody = event.body;
    var buyer_user_id = requestBody.user_id;
    var transaction_id = requestBody.transaction_id;
    var transaction_request = requestBody.request;
    var transaction_biometric = requestBody.biometric;
    
    var curr_time = String(new Date(Date.now()).toString());

    //get users current wallet;
    if(transaction_request == "Cancelled"){
        var params_cancelTransaction = {
              TableName:'paytel-mobilehub-2098009603-transactions',
              Key:{
                  "transaction_id": transaction_id
              },
              UpdateExpression: "SET transaction_status = :rq, time_last_edit = :at",
              ExpressionAttributeValues:{
                 ':rq':transaction_request,
                 ':at': curr_time
              },
              ReturnValues:"NONE"
          };
          docClient.update(params_cancelTransaction, function(err, data) {
                if (err) {
                                    console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                                    Response({message:"DB error_ut"}, 400, context);
                                    return;
                } else {
                                      console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                                      Response({message:"Transaction canceled"}, 200, context);
                 }
                                  
            });
    }else{
    var params_updateTransaction = {
              TableName:'paytel-mobilehub-2098009603-transactions',
              Key:{
                  "transaction_id": transaction_id
              },
              UpdateExpression: "SET biometric_used = :bm, transaction_status = :rq, time_last_edit = :at",
              ExpressionAttributeValues:{
                 ':bm': transaction_biometric,
                 ':rq':transaction_request,
                 ':at': curr_time
              },
              ReturnValues:"NONE"
          };
          
          var params_getWallet = {
            TableName: "paytel-mobilehub-2098009603-user-data",
            Key:{
                "userId": buyer_user_id
            },
            ProjectionExpression:"wallet"
        };
        var params_getTransactionAmount ={
            TableName:'paytel-mobilehub-2098009603-transactions',
              Key:{
                  "transaction_id": transaction_id
              },
              ProjectionExpression:"amount, seller_id"
        }
    docClient.get(params_getWallet, function(err, dataWallet){
        if(err){
            console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
            Response({message:"DB error_un"}, 400, context);
            return;
        }else{
            docClient.get(params_getTransactionAmount, function(err,dataTrans){
                if(err){
                    console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    Response({message:"DB error_un"}, 400, context);
                    return;
                }else{
                    if(dataWallet.Item.wallet === undefined || dataWallet.Item.wallet < dataTrans.Item.amount ){
                        //refuse transaction
                        Response({message:"Insufficient funds"}, 220, context);
                        return;
                    }else{
                        var params_UpdateWallet_seller = {
                             TableName: "paytel-mobilehub-2098009603-user-data",
                            Key:{
                                "userId": dataTrans.Item.seller_id
                            },
                            UpdateExpression: "SET wallet = wallet + :amount",
                            ExpressionAttributeValues:{
                                 ':amount': parseFloat(dataTrans.Item.amount)
                            },
                            ReturnValues:"NONE"
                        }
                        var params_UpdateWallet_buyer = {
                             TableName: "paytel-mobilehub-2098009603-user-data",
                            Key:{
                                "userId": buyer_user_id
                            },
                            UpdateExpression: "SET wallet = wallet - :amount",
                            ExpressionAttributeValues:{
                                 ':amount': parseFloat(dataTrans.Item.amount)
                            },
                            ReturnValues:"NONE"
                        }
                        docClient.update(params_UpdateWallet_buyer, function(err,data){
                            if(err){
                                Response({message:"DB error_uw"}, 400, context);
                                return;
                            }else{
                                 docClient.update(params_UpdateWallet_seller, function(err,data){
                            if(err){
                                Response({message:"DB error_uw"}, 400, context);
                                return;
                            }else{
                                docClient.update(params_updateTransaction, function(err, data) {
                                  if (err) {
                                    console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                                    Response({message:"DB error_ut"}, 400, context);
                                    return;
                                  } else {
                                      console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                                      Response({message:"Transaction processed"}, 200, context);
                                  }
                                  
                                });
                            }
                        });
                            }
                        });
                       
                        
                    }
                }
            });
        }
    });
}
};

function Response(responseBody, responseCode, context){
    var response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "Transaction"
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response));
    context.succeed(response);
}